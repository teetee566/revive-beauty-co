# Revive Beauty Co. — university demonstration store

A responsive storefront for a fictional beauty brand in pink and pastel green.

## Features
- Lipstick (£19), lip liner (£10), lip gloss (£16), build-your-own combo (£40), lipstick refill (£13).
- Select shades for each product and for each component of the combo.
- Optional engraving for lipstick or combo (+£5), with custom text.
- Shopping bag with quantity controls, removal, persistent cart (browser localStorage), and live subtotal.
- Checkout with required contact/delivery fields, delivery options, simulated payment method, calculated total and on-screen order confirmation.
- **Demo only:** no real payments, emails, accounts, backend, order fulfilment or permanent order storage. Do not enter real payment details.

## Preview locally
Open `index.html` in your browser. All assets are local and no build step is needed.

## Publish with GitHub Pages
1. Create a new GitHub repository, e.g. `revive-beauty-co`.
2. Upload **index.html**, **style.css**, and **script.js** to the root of the repository (not inside an extra folder).
3. Open **Settings → Pages → Build and deployment**.
4. Choose **Deploy from a branch**, `main`, `/ (root)`, then **Save**.
5. Wait for GitHub Pages to publish your site and open the link shown in Pages settings.

## Demonstration walkthrough
Select a lipstick, pick a shade, turn on engraving and type a name. Add it to the bag, increase/decrease quantity, then continue to checkout. Enter sample details, select a delivery option, and place a **demo order** to see an order reference and confirmation. Try the £40 lip combo as well.

## Important limitation
The website runs entirely in the browser. The checkout simulates a successful transaction and does **not** validate a card or send an order to a server. For a university demonstration, explain that real payment processing and secure order management would require a payment provider and backend.

## Virtual Studio and shopping assistant
- **Virtual lip try-on:** choose a local selfie, select a lipstick shade, and drag/resize a colour overlay to align it with your lips. This is a manual visual simulation, **not** automatic face detection or an augmented-reality model. Images remain in the browser and are not uploaded.
- **Virtual engraving:** type up to 20 characters and see a live illustration of the engraved case. Add the customised lipstick to the basket for **£24** (£19 lipstick + £5 engraving).
- **Chat assistant:** interactive, rules-based product Q&A about shades, prices, combos, refills, engraving and delivery. It does **not** connect to a generative AI model. To claim actual AI-powered responses, integrate a hosted AI backend with an API key kept server-side; GitHub Pages alone cannot safely store a secret API key.
- **Payments:** fully simulated. No card details, real payments, shipping, or real orders.
